#!/usr/bin/env python
__version__ = '20090824'

if __name__ == '__main__': print __version__
